const express=require("express");
const jwt=require("jsonwebtoken");
const bcrypt=require("bcryptjs");
const cors=require("cors");
const app=express();
const PORT=5000;
const SECRET_KEY="exam_secret_key";
let users=[];
app.use(express.json());
app.use(cors());
app.use(express.static(__dirname));
app.post("/register",async(req,res)=>{
const{username,password}=req.body;
if(!username||!password) return res.status(400).json({message:"All fields required"});
if(users.find(u=>u.username===username)) return res.status(400).json({message:"User already exists"});
users.push({username,password:await bcrypt.hash(password,10)});
res.json({message:"User registered successfully"});
});
app.post("/login",async(req,res)=>{
const{username,password}=req.body;
const user=users.find(u=>u.username===username);
if(!user) return res.status(400).json({message:"Invalid username"});
if(!await bcrypt.compare(password,user.password)) return res.status(400).json({message:"Invalid password"});
const token=jwt.sign({username},SECRET_KEY,{expiresIn:"1h"});
res.json({message:"Login successful",token});
});
const verifyToken=(req,res,next)=>{
const token=req.headers["authorization"]?.split(" ")[1];
if(!token) return res.status(401).json({message:"Access denied"});
jwt.verify(token,SECRET_KEY,(err,decoded)=>{if(err) return res.status(403).json({message:"Invalid token"});req.user=decoded;next();});
};
app.get("/exam",verifyToken,(req,res)=>res.json({
message:`Welcome ${req.user.username}`,
exam:[
{id:1,question:"What is 5 + 5?",options:["8","9","10","11"],answer:"10"},
{id:2,question:"What does JWT stand for?",options:["Java Web Token","JSON Web Token","JavaScript Web Token","Joint Web Token"],answer:"JSON Web Token"}
]
}));
app.listen(PORT,()=>console.log(`Server running at http://localhost:${PORT}`));
